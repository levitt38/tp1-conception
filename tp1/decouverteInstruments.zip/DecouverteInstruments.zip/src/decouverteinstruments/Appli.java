package decouverteinstruments;
      
import java.util.HashMap;
import java.util.Scanner;

public class Appli {
         
private HashMap<String, Instrument> lesInstruments;
private HashMap<String, Enfant> lesEnfants;	

public HashMap<String, Instrument> getInstruments() {
	return lesInstruments;
}

public HashMap<String, Enfant> getEnfants() {
	return lesEnfants;
}

public void setInstruments(HashMap<String, Instrument> lesInstruments) {
        this.lesInstruments = lesInstruments;
    }

public void setEnfants(HashMap<String, Enfant> lesEnfants) {
        this.lesEnfants = lesEnfants;
}

/**
     * Creation d'un nouvel instrument
     * Un message de confimation est affiché à l'issue de la création.
     * Si l'instrument existe déjà, un message d'erreur est affiché
*/
public void nouveauInstrument()	{	
	
}

/**
     * Inscription d'un nouvel enfant
     * Un message de confimation est affiché à l'issue de la création.
     * Un message d'erreur est affiché pour chaque cas d'erreur (enfant déjà inscrit, instrument non existant, mauvais jour)
*/
public void nouvelEnfant(){
 
}
	
/**
     * Inscription d'un enfant pour un autre instrument
     * Un message de confimation est affiché à l'issue de la création.
     * Un message d'erreur est affiché pour chaque cas d'erreur et chaque contrainte non vérifiée
*/
public void ajouterInstrumentEnfant()	{
 	
}

public void afficherInscriptionsEnfants (){
        
}
    
public void afficherInscriptionsInstruments (){
      
}

}





