package decouverteinstruments;


import java.io.Serializable;

public class Instrument implements java.io.Serializable {
	
	
        
}
